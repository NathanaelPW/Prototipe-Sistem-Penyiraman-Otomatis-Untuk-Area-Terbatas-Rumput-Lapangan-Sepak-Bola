import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Inisialisasi Firebase
  runApp(const SmartIrrigationApp());
}

class SmartIrrigationApp extends StatelessWidget {
  const SmartIrrigationApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Irrigation',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        scaffoldBackgroundColor: Colors.grey[100],
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.teal,
            foregroundColor: Colors.white,
            textStyle: const TextStyle(fontSize: 16),
          ),
        ),
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _login() {
    if (_usernameController.text == 'admin' &&
        _passwordController.text == '1234') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => HomePage(username: _usernameController.text),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Invalid credentials'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal[50],
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Card(
              elevation: 12,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(28.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircleAvatar(
                      radius: 38,
                      backgroundColor: Colors.teal[100],
                      child:
                          Icon(Icons.grass, color: Colors.teal[700], size: 48),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Smart Irrigation',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Login to continue',
                      style: TextStyle(fontSize: 16, color: Colors.black54),
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: _usernameController,
                      decoration: const InputDecoration(
                        labelText: 'Username',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.person),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _passwordController,
                      decoration: const InputDecoration(
                        labelText: 'Password',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.lock),
                      ),
                      obscureText: true,
                    ),
                    const SizedBox(height: 28),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.login),
                        label:
                            const Text('Login', style: TextStyle(fontSize: 18)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal[700],
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),
                        onPressed: _login,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String username;
  const HomePage({super.key, required this.username});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();

  Map<String, dynamic> sensorData = {
    'soilMoisture': 0,
    'pH': 0.0,
    'pumpStatus': 'OFF',
    'soilCondition': '',
  };

  int _scheduleDay = 1;
  int _scheduleHour = 6;
  int _scheduleMinute = 0;

  String _schedulePumpStatus = 'OFF';

  bool _welcomeShown = false;

  @override
  void initState() {
    super.initState();
    _listenToSensorData();
    _listenToPumpStatus();

    // Tampilkan welcome hanya sekali saat HomePage pertama kali muncul
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_welcomeShown) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Welcome back, ${widget.username}!'),
            backgroundColor: Colors.teal,
          ),
        );
        _welcomeShown = true;
      }
    });
  }

  void _listenToSensorData() {
    _databaseReference
        .child('sensorData')
        .limitToLast(1)
        .onChildAdded
        .listen((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>;
      setState(() {
        // Hanya update field yang ada di data sensor
        sensorData['soilMoisture'] =
            data['soilMoisture'] ?? sensorData['soilMoisture'];
        sensorData['pH'] = data['pH'] ?? sensorData['pH'];
        sensorData['soilCondition'] =
            data['soilCondition'] ?? sensorData['soilCondition'];
        // pumpStatus TIDAK disentuh di sini!
      });
    });
  }

  void _listenToPumpStatus() {
    _databaseReference.child('pumpControl/command').onValue.listen((event) {
      final command = event.snapshot.value?.toString() ?? 'PUMP_OFF';
      setState(() {
        sensorData['pumpStatus'] = command == 'PUMP_ON' ? 'ON' : 'OFF';
      });
    });
  }

  void _sendPumpCommand(String command) async {
    await _databaseReference.child('pumpControl/command').set(command);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Command "$command" sent!')),
    );
  }

  void _logout() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const LoginPage()),
    );
  }

  void _saveSchedule() {
    final schedule = {
      'day': _scheduleDay,
      'hour': _scheduleHour,
      'minute': _scheduleMinute,
    };
    _databaseReference.child('schedule').update(schedule);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Schedule saved!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 8,
        backgroundColor: Colors.teal[700],
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF26a69a), Color(0xFF80cbc4)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.grass, color: Colors.white, size: 28),
            SizedBox(width: 10),
            Text(
              'Smart Irrigation',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 22,
                color: Colors.white,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: Tooltip(
              message: 'Logout',
              child: GestureDetector(
                onTap: _logout,
                child: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(Icons.logout, color: Colors.teal[700]),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFe0f7fa), Color(0xFFb2dfdb), Color(0xFFf1f8e9)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(18.0),
            child: Column(
              children: [
                // --- Sensor Data Card ---
                Card(
                  elevation: 8,
                  color: Colors.white.withOpacity(0.95),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18)),
                  child: Padding(
                    padding: const EdgeInsets.all(22.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _sensorInfo(
                          icon: Icons.opacity,
                          label: 'Moisture',
                          value: '${sensorData['soilMoisture']}%',
                          color: Colors.blue[700]!,
                          bgColor: Colors.blue[50]!,
                        ),
                        _sensorInfo(
                          icon: Icons.science,
                          label: 'pH',
                          value: '${sensorData['pH']}',
                          color: Colors.deepPurple,
                          bgColor: Colors.purple[50]!,
                        ),
                        _sensorInfo(
                          icon: Icons.terrain,
                          label: 'Condition',
                          value: sensorData['soilCondition'],
                          color: Colors.brown,
                          bgColor: Colors.brown[50]!,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // --- Pump Control Card ---
                Card(
                  elevation: 8,
                  color: Colors.green[50],
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 24.0, horizontal: 12),
                    child: Column(
                      children: [
                        Text(
                          'Manual Control',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.teal[700],
                          ),
                        ),
                        const SizedBox(height: 12),
                        Center(
                          child: GestureDetector(
                            onTap: () {
                              if (sensorData['pumpStatus'] == 'ON') {
                                _sendPumpCommand('PUMP_OFF');
                              } else {
                                _sendPumpCommand('PUMP_ON');
                              }
                            },
                            child: CircleAvatar(
                              radius: 38,
                              backgroundColor: sensorData['pumpStatus'] == 'ON'
                                  ? Colors.green
                                  : Colors.redAccent,
                              child: const Icon(
                                Icons.power_settings_new,
                                color: Colors.white,
                                size: 40,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          sensorData['pumpStatus'] == 'ON'
                              ? 'PUMP ON'
                              : 'PUMP OFF',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: sensorData['pumpStatus'] == 'ON'
                                ? Colors.green
                                : Colors.redAccent,
                          ),
                        ),
                        const SizedBox(height: 10),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.autorenew),
                          label: const Text('Auto Mode'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange[700],
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(24),
                            ),
                          ),
                          onPressed: () => _sendPumpCommand('AUTO_MODE'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // --- Schedule Card ---

                // --- Button ke halaman Set Watering Schedule ---
                Card(
                  elevation: 8,
                  color: Colors.teal[50],
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18)),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 18, horizontal: 20),
                    leading: CircleAvatar(
                      radius: 28,
                      backgroundColor: Colors.teal[100],
                      child: Icon(Icons.schedule,
                          color: Colors.teal[700], size: 36),
                    ),
                    title: const Text(
                      'Set Watering Schedule',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal,
                      ),
                    ),
                    subtitle: const Padding(
                      padding: EdgeInsets.only(top: 6.0),
                      child: Text(
                        'Atur jadwal penyiraman otomatis sesuai kebutuhan tanaman Anda.',
                        style: TextStyle(fontSize: 14, color: Colors.black87),
                      ),
                    ),
                    trailing:
                        const Icon(Icons.arrow_forward_ios, color: Colors.teal),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const SchedulePage()),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 32),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(40),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.teal[100]!, Colors.green[50]!],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: const Text(
                    'Selalu cek kelembaban tanah secara berkala untuk hasil terbaik!',
                    style: TextStyle(
                        fontSize: 15,
                        color: Colors.teal,
                        fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Helper sensorInfo dengan background bulat warna berbeda
Widget _sensorInfo({
  required IconData icon,
  required String label,
  required String value,
  required Color color,
  Color? bgColor,
}) {
  return Column(
    children: [
      CircleAvatar(
        backgroundColor: bgColor ?? Colors.grey[200],
        radius: 26,
        child: Icon(icon, color: color, size: 28),
      ),
      const SizedBox(height: 8),
      Text(
        value,
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
      Text(
        label,
        style: const TextStyle(fontSize: 14, color: Colors.black87),
      ),
    ],
  );
}

class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key});

  @override
  State<SchedulePage> createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();

  int _scheduleDay = 1;
  int _scheduleHour = 6;
  int _scheduleMinute = 0;
  String _schedulePumpStatus = 'OFF';
  List<Map<String, dynamic>> _history = [];

  @override
  void initState() {
    super.initState();
    _loadCurrentSchedule();
    _loadScheduleHistory();
    _listenToSchedulePumpStatus(); // <-- pastikan ini dipanggil
  }

  void _listenToSchedulePumpStatus() {
    _databaseReference
        .child('sensorData')
        .limitToLast(1)
        .onChildAdded
        .listen((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>;
      setState(() {
        _schedulePumpStatus =
            (data['pumpStatus'] ?? 'OFF').toString().toUpperCase();
      });
    });
  }

  void _loadCurrentSchedule() async {
    final snapshot = await _databaseReference.child('schedule').get();
    if (snapshot.exists) {
      final data = snapshot.value as Map<dynamic, dynamic>;
      setState(() {
        _scheduleDay = data['day'] ?? 1;
        _scheduleHour = data['hour'] ?? 6;
        _scheduleMinute = data['minute'] ?? 0;
      });
    }
  }

  void _loadScheduleHistory() {
    _databaseReference.child('schedule_history').onValue.listen((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data != null) {
        final List<Map<String, dynamic>> history = [];
        data.forEach((key, value) {
          history.add({
            'timestamp': key,
            'day': value['day'],
            'hour': value['hour'],
            'minute': value['minute'],
          });
        });
        history.sort((a, b) => b['timestamp'].compareTo(a['timestamp']));
        setState(() {
          _history = history;
        });
      }
    });
  }

  void _saveSchedule() async {
    final schedule = {
      'day': _scheduleDay,
      'hour': _scheduleHour,
      'minute': _scheduleMinute,
    };
    await _databaseReference.child('schedule').set(schedule);

    // Simpan ke history (dengan timestamp)
    final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    await _databaseReference.child('schedule_history/$timestamp').set(schedule);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Schedule saved!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Set Watering Schedule'),
        backgroundColor: Colors.teal[700],
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Tambahkan di sini
            Padding(
              padding: const EdgeInsets.only(bottom: 16.0),
              child: Row(
                children: [
                  Icon(
                    Icons.power_settings_new,
                    color: _schedulePumpStatus == 'ON'
                        ? Colors.green
                        : Colors.redAccent,
                    size: 28,
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'Pump Status: ',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    _schedulePumpStatus,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: _schedulePumpStatus == 'ON'
                          ? Colors.green
                          : Colors.redAccent,
                    ),
                  ),
                ],
              ),
            ),
            Card(
              elevation: 6,
              color: Colors.teal[50],
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18)),
              child: Padding(
                padding: const EdgeInsets.all(22.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Set Schedule',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            value: _scheduleDay,
                            decoration: const InputDecoration(
                              labelText: 'Day',
                              border: OutlineInputBorder(),
                            ),
                            items: List.generate(
                              7,
                              (i) => DropdownMenuItem(
                                value: i + 1,
                                child: Text([
                                  'Sen',
                                  'Sel',
                                  'Rab',
                                  'Kam',
                                  'Jum',
                                  'Sab',
                                  'Min'
                                ][i]),
                              ),
                            ),
                            onChanged: (val) =>
                                setState(() => _scheduleDay = val ?? 1),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            initialValue: _scheduleHour.toString(),
                            decoration: const InputDecoration(
                              labelText: 'Hour',
                              border: OutlineInputBorder(),
                            ),
                            keyboardType: TextInputType.number,
                            onChanged: (val) =>
                                _scheduleHour = int.tryParse(val) ?? 6,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            initialValue: _scheduleMinute.toString(),
                            decoration: const InputDecoration(
                              labelText: 'Minute',
                              border: OutlineInputBorder(),
                            ),
                            keyboardType: TextInputType.number,
                            onChanged: (val) =>
                                _scheduleMinute = int.tryParse(val) ?? 0,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Center(
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.save),
                        label: const Text('Save Schedule'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal[700],
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              vertical: 14, horizontal: 32),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(24),
                          ),
                        ),
                        onPressed: _saveSchedule,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'History',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.teal,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: _history.isEmpty
                  ? const Center(child: Text('No schedule history yet.'))
                  : ListView.builder(
                      itemCount: _history.length,
                      itemBuilder: (context, index) {
                        final item = _history[index];
                        final dt = DateTime.fromMillisecondsSinceEpoch(
                            int.parse(item['timestamp']));
                        final dayNames = [
                          'Senin',
                          'Selasa',
                          'Rabu',
                          'Kamis',
                          'Jumat',
                          'Sabtu',
                          'Minggu'
                        ];
                        final dayIndex = (item['day'] ?? 1) - 1;
                        final dayName = (dayIndex >= 0 && dayIndex < 7)
                            ? dayNames[dayIndex]
                            : 'Tidak diketahui';
                        return Card(
                          child: ListTile(
                            leading:
                                const Icon(Icons.history, color: Colors.teal),
                            title: Text(
                                'Day: $dayName, Hour: ${item['hour']}, Minute: ${item['minute']}'),
                            subtitle: Text(
                                '${dt.day}/${dt.month}/${dt.year} ${dt.hour}:${dt.minute.toString().padLeft(2, '0')}'),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
